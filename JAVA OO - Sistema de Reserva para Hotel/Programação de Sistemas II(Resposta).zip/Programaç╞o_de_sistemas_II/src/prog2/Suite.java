package prog2;

public class Suite {
	int numeroSuite;
	String tipo;
	int capacidadeSuite;
	int valorDiaria;
	int numero;

	public Suite() {
		
	}

	public int numeroSuite (int numeroSuite) {
		return numeroSuite;
	}

	public String tipo (String tipo) {
		 return tipo;
	}

	public int capacidadeDePessoas (int capacidadeDePessoas) {
		return capacidadeDePessoas ;
	}
	
	public int valorDiaria(int valorDiaria) {
		return valorDiaria;
	}
	
	public int numero(int numero) {
		return numero;
	}
	
	
	
}
